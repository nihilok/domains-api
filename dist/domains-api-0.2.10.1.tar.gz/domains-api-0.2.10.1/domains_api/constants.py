# import os
# from pathlib import Path
#
# with open(Path(os.path.dirname(__file__)) / 'version.txt', 'r') as f:
#     __VERSION__ = f.read().strip()

__VERSION__ = '0.2.10.1'
