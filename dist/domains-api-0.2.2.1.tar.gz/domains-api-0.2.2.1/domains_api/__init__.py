# import sys
#
# from .file_handlers import FileHandlers
# from .ip_checker import BaseUser, IPChecker
# from .ip_changer import DomainsUser, IPChanger
#
#
# if __name__ == '__main__':
#     IPChanger(sys.argv[1:])