import sys

from . import IPChanger

if __name__ == '__main__':
    IPChanger(sys.argv[1:])